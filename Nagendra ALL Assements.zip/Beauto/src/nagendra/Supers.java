package nagendra;

import nagendra.Tree.Treestype;

class Tree{
	String treename="mango tree";
	String colour="green";
class TreesType extends Tree{
	String treename="apple tree";
	
	
}
void printMessage() {
	System.out.println(treename);
	//System.out.println(super.treename);
	System.out.println(colour);
	//System.out.println(super.colour);
}
	
}
public class Supers {

	public static void main(String[] args) {
		Treesype ts=new Treestype();
		ts.printMessage();

	}

}
