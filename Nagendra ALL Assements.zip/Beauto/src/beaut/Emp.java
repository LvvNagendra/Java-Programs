package beaut;

public class Emp {
	private static String empName;
	public String getEmpName() {
		return empName;
		
	}

	public static void main(String[] args) {
		if (empName.equals("nani")) {
		this. empName=empName;
		else
		
	}

}
}