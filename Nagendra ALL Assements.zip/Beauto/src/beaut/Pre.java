package beaut;

public class Pre {

	public static void main(String[] args) {
		int n=100;
		int a=100;
		System.out.println(++n);
		System.out.println(--n);
		System.out.println(n-a++);

	}

}
