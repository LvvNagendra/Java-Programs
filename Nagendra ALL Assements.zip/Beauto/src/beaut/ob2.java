package beaut;

public class ob2 {

}
