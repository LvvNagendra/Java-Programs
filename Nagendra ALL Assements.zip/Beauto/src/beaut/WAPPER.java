package beaut;

import java.util.concurrent.atomic.AtomicInteger;

public class WAPPER {

	public static void main(String[] args) {
		int i= 5;
				//Integer a= Integer.valueOf(i);
		Integer a =new Integer(i);
				System.out.println(a+" "+i);

}}
