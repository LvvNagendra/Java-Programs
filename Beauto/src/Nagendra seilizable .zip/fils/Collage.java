package fils;

import java.io.Serializable;

public class Collage implements Serializable {
			int regId;
			String collageName;

			public Collage(int regId, String collageName) {
				this.regId = regId;
				this.collageName = collageName;
			}
		}

	


